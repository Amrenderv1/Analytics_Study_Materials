# Author: Thomas George Thomas
select count(city) - count(distinct city) from station;
