# Author: Thomas George Thomas
Select name from city where population > 120000 and Countrycode = "USA";