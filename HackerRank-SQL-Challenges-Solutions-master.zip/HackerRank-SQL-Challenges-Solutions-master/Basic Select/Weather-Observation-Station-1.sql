# Author: Thomas George Thomas
select city,State from station;
