# Author: Thomas George Thomas
select name from employee order by name;