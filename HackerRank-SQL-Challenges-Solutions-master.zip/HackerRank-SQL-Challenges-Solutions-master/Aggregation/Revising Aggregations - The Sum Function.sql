# Author: Thomas George Thomas
SELECT SUM(POPULATION)
FROM CITY
WHERE DISTRICT = 'California'
